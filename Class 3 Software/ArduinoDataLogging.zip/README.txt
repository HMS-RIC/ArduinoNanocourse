# Arduino Serial Parsing Examples

This directory contains some very simple examples of how to send data from your Arduino to a computer over the Serial/USB connection.


## serial_random_number_gen
This program runs on your Arduino. It send a random number over the Serial connection every second. This is just a placeholder for the useful data (like timing information) that a real Ardunio program might want to send.

One you have serial_random_number_gen running on your Arduino, you can confirm that it works by opening the Serial Monitor window. Now you can pick one of the programs below to run you your computer to actually read and process the data in a programming language of your choice (Matlab, Python, R).


# (Matlab/R/Python)-SerialDataLogger
These are simple programs that open up the Serial connection to your Ardunio and read in the numeric data that it sends. To keep things simple, these programs do nothing more than save this data to a file. But you could just as easily perform some computation, display the data to a graph, or do anything else with it that your computer is capable of.



NOTE: Only one program on your computer can read from the Serial connection at a time. Please make sure you close the Arduino Serial Monitor window before running (Matlab/R/Python)-SerialDataLogger.
