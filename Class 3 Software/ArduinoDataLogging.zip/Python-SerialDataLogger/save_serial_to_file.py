#!/usr/bin/env python

# You will need pyserial installed for this to work
import serial


# set the port to be whatever is reported in the Arduino IDE under:
# Tools -> Port
# the format should be the following
#   windows: COMX (for example: COM7)
#   linux: /dev/ttyACMX (for example: /dev/ttyACM0)
#   mac: /dev/cu.usbmodemX (for example: /dev/cu.usbmodem1411)
port = 'COM20'

# set this to the filename you want to use when writing the output
filename = 'data.txt'

# set this to the baud rate used for Serial.begin on the Arduino
baudrate = 9600

# open both the serial port (conn) and output file (f)
with serial.Serial(port, baudrate) as conn, open(filename, 'w') as f:
    print("Writing to file: %s, press Ctrl+c to exit" % filename)
    # continue as long as the connection is readable
    while conn.readable():
        try:
            # read in a line from the serial port
            l = conn.readline()
            # write the line to the file using endline \n as the line ending
            f.write(l.decode('ascii').strip() + '\n')
        except KeyboardInterrupt:
            # catch Ctrl-C to exit cleanly
            break
