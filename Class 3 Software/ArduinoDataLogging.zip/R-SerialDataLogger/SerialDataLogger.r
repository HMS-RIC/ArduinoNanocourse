
#### user-settable parameters:
# set the port to be whatever is reported in the Arduino IDE under:
# Tools -> Port
# the format should be the following
#   windows: COMX (for example: COM7)
#   linux: /dev/ttyACMX (for example: /dev/ttyACM0)
#   mac: /dev/cu.usbmodemX (for example: /dev/cu.usbmodem1411)
arduinoPort <- "/dev/cu.usbmodem1411" # port to monitor

recDuration <- 30 # number of seconds to monitor serial port
recInterval <- 2 # number of seconds between recording observations
dataFile <- "~/Desktop/test/RserialMonitorTest.csv" # file to place recorded data
####


endTime <- Sys.time()+recDuration

# connection to monitor
arduinoCon <-
  file(arduinoPort, open = "r")

# dataframe to store readings
readingDF <- data.frame()

while(Sys.time()<endTime){
  readingRow <- cbind.data.frame(
    Sys.time(),
    scan(arduinoCon, n=1)
  )
  readingDF <- rbind.data.frame(
    readingDF,
    readingRow
  )
  Sys.sleep(recInterval)
}

colnames(readingDF) <- c("time","reading")

close(arduinoCon)

write.csv(
  readingDF,
  dataFile,
  row.names = FALSE
)
