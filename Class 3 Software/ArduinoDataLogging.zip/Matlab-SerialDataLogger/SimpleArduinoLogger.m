
%% simpleArduinoLogger()
%	Run this command to log serial input from a connected Arduino.
%	The command will first connect to the Arduino and prompt the user to create a log file.
%   Then it will accept each new line of input from the Arduino and save it to the file
%	in addition to writing it to the Matlab command window.
%
%	Optional parameter: baudRate
%	The default is 9600 (if you call the function with no paramter).
%	Otherwise you may use this paramter to specify a different baud rate.

function simpleArduinoLogger(baudRate)

	% try to find a serial port with an Arduino attached
	arduinoPortName = findFirstArduinoPort();
	if isempty(arduinoPortName)
	    disp('Can''t find serial port with Arduino')
	    return
	end

	% query user for log file name & location
	[FileName, PathName] = uiputfile('*.*', 'New Arduino Log File', 'Arduino.log');
	fullName = fullfile(PathName, FileName);
	logFile = fopen(fullName, 'w');

	% Define the serial port object.
	fprintf('Starting serial on port: %s\n', arduinoPortName);
	serialPort = serial(arduinoPortName);
	global arduinoPort
	arduinoPort = serialPort;
	fprintf('## To terminate, run "global arduinoPort; fclose(arduinoPort)" ##\n\n');

	% Set the baud rate
	serialPort.BaudRate = 9600;
	if (nargin >= 1)
		serialPort.BaudRate = baudRate;
	end

	% Define the function to be executed whenever 1 new line is available
	% to be read from the serial port.
	serialPort.BytesAvailableFcnMode = 'terminator';
    serialPort.Terminator = 'CR/LF'; % Ardunio println() commands uses CR/LN termination
	serialPort.BytesAvailableFcn = @(~,~)logLine(serialPort, logFile);

	% Open the serial port for reading and writing.
	fopen(serialPort);

end

function logLine(serialPort, logFile)
	% read next line from Arduino
	message = fgetl(serialPort);
	% print to screen and save to file
	fprintf(logFile, '%s\n', message);
	fprintf('From Arduino: %s\n', message);
end

function port = findFirstArduinoPort()
	% finds the first port with an Arduino on it.

	serialInfo = instrhwinfo('serial');
	archstr = computer('arch');

	port = [];

	% OSX code:
	if strcmp(archstr,'maci64')
	    for portN = 1:length(serialInfo.AvailableSerialPorts)
	        portName = serialInfo.AvailableSerialPorts{portN};
	        if strfind(portName,'tty.usbmodem')
	            port = portName;
	            return
	        end
	        if strfind(portName,'cu.usbmodem')
	            port = portName;
	            return
	        end
	    end
	else
	% PC code:
	    % code from Benjamin Avants on Matlab Answers
	    % http://www.mathworks.com/matlabcentral/answers/110249-how-can-i-identify-com-port-devices-on-windows

	    Skey = 'HKEY_LOCAL_MACHINE\HARDWARE\DEVICEMAP\SERIALCOMM';
	    % Find connected serial devices and clean up the output
	    [~, list] = dos(['REG QUERY ' Skey]);
	    list = strread(list,'%s','delimiter',' ');
	    coms = 0;
	    for i = 1:numel(list)
	      if strcmp(list{i}(1:3),'COM')
	            if ~iscell(coms)
	                coms = list(i);
	            else
	                coms{end+1} = list{i};
	            end
	        end
	    end
	    key = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Enum\USB\';
	    % Find all installed USB devices entries and clean up the output
	    [~, vals] = dos(['REG QUERY ' key ' /s /f "FriendlyName" /t "REG_SZ"']);
	    vals = textscan(vals,'%s','delimiter','\t');
	    vals = cat(1,vals{:});
	    out = 0;
	    % Find all friendly name property entries
	    for i = 1:numel(vals)
	        if strcmp(vals{i}(1:min(12,end)),'FriendlyName')
	            if ~iscell(out)
	                out = vals(i);
	            else
	                out{end+1} = vals{i};
	            end
	        end
	    end
	    % Compare friendly name entries with connected ports and generate output
	    for i = 1:numel(coms)
	        match = strfind(out,[coms{i},')']);
	        ind = 0;
	        for j = 1:numel(match)
	            if ~isempty(match{j})
	                ind = j;
	            end
	        end
	        if ind ~= 0
	            com = str2double(coms{i}(4:end));
	            % Trim the trailing ' (COM##)' from the friendly name - works on ports from 1 to 99
	            if com > 9
	                len = 8;
	            else
	                len = 7;
	            end
	            devs{i,1} = out{ind}(27:end-len);
	            devs{i,2} = coms{i};
	        end
	    end
	    % get the first arduino port
	    for i = 1:numel(coms)
	        [portFriendlyName, portName] = devs{i,:};
	        if ~isempty(portFriendlyName)
		        if contains(portFriendlyName, 'Arduino') ...
		        		|| contains(portFriendlyName, 'Teensy')
		            port = portName;
		            return
		        end
	        end
	    end
	end
end % findFirstArduinoPort()
